Made by: Vimlark

Originally created for the game Flyer Kid
https://vimlark.itch.io/flyer-kid


License Permissions:

You can do:

- You can use these asset for personal and commercial purposes. Credit is not required but would be appreciated. 

- Modify to suit your needs.

You cannot do:

- Resell/redistribute these assets.